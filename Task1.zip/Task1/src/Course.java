public class Course {
    String name;

    public Course(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}